using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OcultaScript : MonoBehaviour
{
    public GameObject plataforma;
    // Start is called before the first frame update
    void Start()
    {
        plataforma.SetActive(false);
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
